# BSim

BSim is a behavior based robot simulator.

Downloaded from: http://www.behaviorbasedprogramming.net/

## Installation

BSim applet can NOT be run in modern browsers. Browsers do not allow running Java applets anymore, because of security reasons.
Solution is to run applets using *appletviewer*, a tool that is included in the Java SDK (bin directory).

Download and install Java JDK from:
http://www.oracle.com/technetwork/java/javase/downloads/index.html

## Run BSim

Execute (double-click on) commandfile *bsim.bat*.

You amy have to change this file to point to the correct location of the appletviewer file.




